"""Showdown scraping helpers."""
